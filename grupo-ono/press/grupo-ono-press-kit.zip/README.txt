GRUPO ONO · PRESS KIT

Images: courtesy of Grupo ONO.
Press contact: jaimeloralondono@gmail.com
Website: https://grupo-ono.com

grupo-ono-fact-sheet.pdf   One-page fact sheet (A4): who we are, timeline, venues, press.

01-logos
  grupo-ono-logo.svg                           vector  Grupo ONO logo, ink (#111111).
  grupo-ono-logo-ink.png                    2000x1105  Grupo ONO logo, ink on transparent.
  grupo-ono-logo-paper.png                  2000x1105  Grupo ONO logo, paper (#F4EFE7) on transparent, for dark backgrounds.
  ono-hosomaki-bar-logo.png                   200x200  ONO Hosomaki Bar logo, black on transparent.
  casa-salvaje-logo-gold.png                  500x650  Casa Salvaje logo, gold on transparent.

02-ono  ONO: campaign art, and renders of ONO Cartagena
  ono-red-oni.jpg                           1122x1402  Unmask your Oni: red Oni mask with a white snake. Campaign art.
  ono-green-oni.jpg                         1122x1402  Unmask your Oni: green Oni mask. Campaign art.
  ono-oni-masks.jpg                         1122x1402  Unmask your Oni: twenty masks on a cream poster. Campaign art.
  ono-beneath-the-skin-tuna.jpg              941x1672  Beneath the skin: tattooed tuna. Campaign art.
  ono-tokyo-stamp-oni.jpg                   1122x1402  Tokyo stamps: an Oni mask on a postage stamp. Campaign art.
  ono-engraving-waves.jpg                    941x1672  Engraving with herons and waves. Campaign art.
  ono-anatomy-ono-roll.jpg                  1122x1402  Anatomy of a roll: the ONO roll. Campaign art.
  ono-anatomy-salmon-nigiri.jpg             1122x1402  Anatomy of a nigiri: king salmon. Campaign art.

  The four files named ono-cartagena-render-*.jpg are RENDERS of ONO Cartagena,
  not photographs. ONO Cartagena opens inside Casa Salvaje in November – December 2026.
  ono-cartagena-render-bar.jpg               1210x423  Render of ONO Cartagena: the bar under the wooden beams.
  ono-cartagena-render-red-room.jpg          1210x422  Render of ONO Cartagena: lit shoji panels and red screens over the DJ booth.
  ono-cartagena-render-samurai.jpg           1210x423  Render of ONO Cartagena: samurai armour in the shoji-panel corridor.
  ono-cartagena-render-geisha.jpg            1210x423  Render of ONO Cartagena: shoji panels and a geisha portrait.

03-casa-salvaje  Casa Salvaje, Cartagena
  casa-salvaje-door.jpg                      800x1000  The wooden door on Calle Santa Teresa with the jaguar plaque.
  casa-salvaje-slvj-table.jpg                750x1000  An SLVJ table from above, set with illustrated plates. Photograph.
  casa-salvaje-kanibal-table.jpg             750x1000  A Kanibal table from above, with plates to share. Photograph.
  casa-salvaje-slvj-room.jpg                1536x1024  The SLVJ dining room at night, under the fibre lamps and the neon. Photograph.
  casa-salvaje-slvj-guests.jpg               1000x665  Guests at SLVJ. Photograph.
  casa-salvaje-kanibal-room.jpg              1000x666  The Kanibal dining room, full, under the paper lamps. Photograph.
  casa-salvaje-map.jpg                      1120x1400  The house awaits: illustrated map of the Old City around Casa Salvaje.
  casa-salvaje-after-dark.jpg               1122x1402  After dark: a roaring leopard on black. Campaign art.
  casa-salvaje-mosaic-jaguar.jpg            1122x1402  A mosaic jaguar on green tile, with a glass. Campaign art.
  casa-salvaje-slvj-wild-edition.jpg        1122x1402  SLVJ, The Wild Edition: the jaguar issue. Campaign art.
  casa-salvaje-kanibal-steak.jpg            1086x1448  Kanibal glyphs: a steak marked in red. Campaign art.
  casa-salvaje-la-domenica-lemon.jpg        1122x1402  La Domenica, Sundays supersized: the lemon. Campaign art.
